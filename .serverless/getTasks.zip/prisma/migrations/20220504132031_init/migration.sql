-- CreateTable
CREATE TABLE "tasks" (
    "id" TEXT NOT NULL,

    CONSTRAINT "tasks_pkey" PRIMARY KEY ("id")
);
